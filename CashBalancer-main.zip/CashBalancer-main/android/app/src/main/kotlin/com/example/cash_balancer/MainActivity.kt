package com.bernaferrari.cash_balancer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
