import '../database.dart';

Database constructDb({bool logStatements = false}) {
  throw 'Platform not supported';
}
